import java.util.*;

public class AttributeSet extends HashSet<Attribute> {

	public AttributeSet() {
		super();
	}

	public AttributeSet(AttributeSet other) {
		super(other);
	}
}